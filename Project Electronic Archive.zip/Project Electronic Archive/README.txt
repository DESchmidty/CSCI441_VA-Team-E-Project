In order by directory the list of files of the project follows;

Backend Folder:
	env: file containing environment variables for mongodb
	cars.js: contains car schema and api functions to connect to database
	customers.js: contains customer schema and api functions for database connection
	server.js: contains server information, cors options and mondodb connection routes

Build Folder:
	Compiled build to serve as the project being hosted.

Public Folder:
	contains default index file, icons and logos not necessarily used in project.

Src folder:
	Components Subfolder:
		navbar.js and css: serves the navigation dropdown menu and graphics
Pages Subfolder:
		CarSearch.js: serves the car search page and contains functions to handle options
		Contact.js: contains basic "store" contact information
		Customerinformation.js: serves the booking page with a post function to add new customers
		HomePage.js and css: serves the homepage and graphics for the page
		ManageCustomers: Admin page to adjust customer info in the database

	App.js and css: imports various pages and adjusts routes for the navbar with graphics
	index.js and css: default files provided with template
	ManageVehicles.js: admin page to adjust vehicle info in the database
	reportWebVitals.js and setupTests.js: unused default files from template

How to run:
	So we did not deploy this project, nor did we develop an executable for it; as such it must be compiled with a build and deployed locally -- in this case using node.js. Using node, navigate to the server.js files directory, use "npm install" to install all of which needs to be installed from the package.lock file, afterwards using "npm run build" will compile the build if it is not there already. Finally, using the "node server.js" command will boot up the build locally on localhost:3000 in which the site can be accessed.
	There is no log in and nothing will be to be authenticated, the project is rather simple, so clicking the book button on a selected car will take the user to a page to enter customer information which will be tied to the vehicles id which can be viewed on the manage customers page. 

	If for some reason npm install does not install all of the required files, a list written below are some of the big ones that are used, and should install all of the smaller ones, in no particular order. Installed with "npm install filename"
		express
		mongoose
		cors
		dotenv
		react
	